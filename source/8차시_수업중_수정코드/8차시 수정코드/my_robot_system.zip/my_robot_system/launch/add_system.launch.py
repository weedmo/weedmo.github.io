from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    launch_description = LaunchDescription()

    sensor_node = Node(
        package="my_robot_system",
        executable="sensor_node",
        name="sensor_node",
        output="screen",
    )

    manager_node = Node(
        package="my_robot_system",
        executable="manager_node",
        name="manager_node",
        output="screen",
    )

    cooler_node = Node(
        package="my_robot_system",
        executable="cooler_service",
        name="cooler_service",
        output="screen",
    )

    switch_node = Node(
        package="my_robot_system",
        executable="switch_action_server",
        name="switch_action_server",
        output="screen",
    )

    launch_description.add_action(sensor_node)
    launch_description.add_action(manager_node)
    launch_description.add_action(cooler_node)
    launch_description.add_action(switch_node)

    return launch_description
